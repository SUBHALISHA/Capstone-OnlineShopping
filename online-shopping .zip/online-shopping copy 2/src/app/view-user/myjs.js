/*$('#userModal').on('show.bs.modal', function (event) {
    var button = $(event.relatedTarget) // Button that triggered the modal
    var user = button.data('whatever') // Extract info from data-* attributes
   
    var modal = $(this)
    modal.find('.modal-title').text('Name ' + user)
    modal.find('.modal-body #name').val(user.name)
})*/
