export const CATEGORIES =[
    {
        name:"Baby Clothing",
        value:"BC"
    },
    {
        name:"Men Wear",
        value:"MW"
    },
    {
        name:"Girls Fashion",
        value:"GF"
    },
    {
        name:"Electronics",
        value:"EC"
    },
    {
        name:"Cosmetics",
        value:"CS"
    },
    {
        name:"Grocery",
        value:"GC"
    },
    {
        name:"Health & Personal Care",
        value:"HP"
    },
    {
        name:"Sports",
        value:"SP"
    }
]