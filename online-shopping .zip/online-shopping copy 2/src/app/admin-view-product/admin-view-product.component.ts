import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-admin-view-product',
  templateUrl: './admin-view-product.component.html',
  styleUrls: ['./admin-view-product.component.css']
})
export class AdminViewProductComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
